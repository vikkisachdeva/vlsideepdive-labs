#include "ffi.h"
#include <stdio.h>
#include <stdlib.h>
ffi_type ffi_type_void, ffi_type_uint8, ffi_type_sint8, ffi_type_uint16, ffi_type_sint16, ffi_type_uint32, ffi_type_sint32,
  ffi_type_uint64, ffi_type_sint64, ffi_type_float, ffi_type_double, ffi_type_pointer;
ffi_status ffi_prep_cif(ffi_cif *c, ffi_abi a, unsigned n, ffi_type *r, ffi_type **t) { (void)c; (void)a; (void)n; (void)r; (void)t; return FFI_BAD_ABI; }
void ffi_call(ffi_cif *c, void (*f)(void), void *r, void **a) { (void)c; (void)f; (void)r; (void)a; fprintf(stderr, "foreign subprograms are not supported here\n"); abort(); }
