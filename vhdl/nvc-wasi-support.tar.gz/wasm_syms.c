#include <string.h>
#include <stddef.h>
void _nvc_add_cover_item(void *);
static void w_nvc_add_cover_item(void *a, void *t) { (void)a; (void)t; _nvc_add_cover_item(a); }
void _nvc_create_cover_scope(void *);
static void w_nvc_create_cover_scope(void *a, void *t) { (void)a; (void)t; _nvc_create_cover_scope(a); }
void _nvc_current_delta(void *, void *);
static void w_nvc_current_delta(void *a, void *t) { (void)a; (void)t; _nvc_current_delta(a, t); }
void _nvc_ieee_warnings(void *, void *);
static void w_nvc_ieee_warnings(void *a, void *t) { (void)a; (void)t; _nvc_ieee_warnings(a, t); }
void _nvc_increment_cover_item(void *);
static void w_nvc_increment_cover_item(void *a, void *t) { (void)a; (void)t; _nvc_increment_cover_item(a); }
void _nvc_random_get_next(void *);
static void w_nvc_random_get_next(void *a, void *t) { (void)a; (void)t; _nvc_random_get_next(a); }
void _nvc_set_cover_scope_name(void *);
static void w_nvc_set_cover_scope_name(void *a, void *t) { (void)a; (void)t; _nvc_set_cover_scope_name(a); }
void _polyfill_to_ostring_bit_vec(void *, void *);
static void w_polyfill_to_ostring_bit_vec(void *a, void *t) { (void)a; (void)t; _polyfill_to_ostring_bit_vec(a, t); }
void _polyfill_to_string_real_format(void *, void *);
static void w_polyfill_to_string_real_format(void *a, void *t) { (void)a; (void)t; _polyfill_to_string_real_format(a, t); }
void _std_env_clear_vhdl_assert(void);
static void w_std_env_clear_vhdl_assert(void *a, void *t) { (void)a; (void)t; _std_env_clear_vhdl_assert(); }
void _std_env_get_assert_format(void *, void *);
static void w_std_env_get_assert_format(void *a, void *t) { (void)a; (void)t; _std_env_get_assert_format(a, t); }
void _std_env_get_call_path(void *, void *);
static void w_std_env_get_call_path(void *a, void *t) { (void)a; (void)t; _std_env_get_call_path(a, t); }
void _std_env_get_vhdl_assert_count(void *);
static void w_std_env_get_vhdl_assert_count(void *a, void *t) { (void)a; (void)t; _std_env_get_vhdl_assert_count(a); }
void _std_env_get_vhdl_assert_enable(void *);
static void w_std_env_get_vhdl_assert_enable(void *a, void *t) { (void)a; (void)t; _std_env_get_vhdl_assert_enable(a); }
void _std_env_get_workingdir(void *, void *);
static void w_std_env_get_workingdir(void *a, void *t) { (void)a; (void)t; _std_env_get_workingdir(a, t); }
void _std_env_getenv(void *, void *);
static void w_std_env_getenv(void *a, void *t) { (void)a; (void)t; _std_env_getenv(a, t); }
void _std_env_set_assert_format(void *, void *);
static void w_std_env_set_assert_format(void *a, void *t) { (void)a; (void)t; _std_env_set_assert_format(a, t); }
void _std_env_set_assert_format_valid(void *, void *);
static void w_std_env_set_assert_format_valid(void *a, void *t) { (void)a; (void)t; _std_env_set_assert_format_valid(a, t); }
void _std_env_set_vhdl_assert_enable(void *);
static void w_std_env_set_vhdl_assert_enable(void *a, void *t) { (void)a; (void)t; _std_env_set_vhdl_assert_enable(a); }
void _std_env_stop(void *);
static void w_std_env_stop(void *a, void *t) { (void)a; (void)t; _std_env_stop(a); }
void _std_env_tool_version(void *, void *);
static void w_std_env_tool_version(void *a, void *t) { (void)a; (void)t; _std_env_tool_version(a, t); }
void _std_env_vhdl_version(void *, void *);
static void w_std_env_vhdl_version(void *a, void *t) { (void)a; (void)t; _std_env_vhdl_version(a, t); }
void _std_to_string_real(void *, void *);
static void w_std_to_string_real(void *a, void *t) { (void)a; (void)t; _std_to_string_real(a, t); }
static const struct { const char *name; void (*fn)(void *, void *); } wasm_syms[] = {
  { "_nvc_add_cover_item", w_nvc_add_cover_item },
  { "_nvc_create_cover_scope", w_nvc_create_cover_scope },
  { "_nvc_current_delta", w_nvc_current_delta },
  { "_nvc_ieee_warnings", w_nvc_ieee_warnings },
  { "_nvc_increment_cover_item", w_nvc_increment_cover_item },
  { "_nvc_random_get_next", w_nvc_random_get_next },
  { "_nvc_set_cover_scope_name", w_nvc_set_cover_scope_name },
  { "_polyfill_to_ostring_bit_vec", w_polyfill_to_ostring_bit_vec },
  { "_polyfill_to_string_real_format", w_polyfill_to_string_real_format },
  { "_std_env_clear_vhdl_assert", w_std_env_clear_vhdl_assert },
  { "_std_env_get_assert_format", w_std_env_get_assert_format },
  { "_std_env_get_call_path", w_std_env_get_call_path },
  { "_std_env_get_vhdl_assert_count", w_std_env_get_vhdl_assert_count },
  { "_std_env_get_vhdl_assert_enable", w_std_env_get_vhdl_assert_enable },
  { "_std_env_get_workingdir", w_std_env_get_workingdir },
  { "_std_env_getenv", w_std_env_getenv },
  { "_std_env_set_assert_format", w_std_env_set_assert_format },
  { "_std_env_set_assert_format_valid", w_std_env_set_assert_format_valid },
  { "_std_env_set_vhdl_assert_enable", w_std_env_set_vhdl_assert_enable },
  { "_std_env_stop", w_std_env_stop },
  { "_std_env_tool_version", w_std_env_tool_version },
  { "_std_env_vhdl_version", w_std_env_vhdl_version },
  { "_std_to_string_real", w_std_to_string_real },
};
void *wasm_find_internal(const char *name) { for (size_t i = 0; i < sizeof(wasm_syms) / sizeof(wasm_syms[0]); i++) if (strcmp(wasm_syms[i].name, name) == 0) return (void *)wasm_syms[i].fn; return NULL; }
