#!/bin/bash
# Configure + build nvc for WebAssembly (WASI). Usage: build-nvc.sh [configure]
set -e
W=/home/claude/vsim/wasi-sdk-25.0-x86_64-linux
D=/tmp/claude-0/wasi-deps
EMU="-D_WASI_EMULATED_SIGNAL -D_WASI_EMULATED_PROCESS_CLOCKS -D_WASI_EMULATED_MMAN -D_WASI_EMULATED_GETPID"
export PKG_CONFIG_LIBDIR=$D/lib/pkgconfig PKG_CONFIG_PATH= PTHREAD_CFLAGS="-D_WASI_EMULATED_PTHREAD" PTHREAD_LIBS="-lwasi-emulated-pthread"
export LIBS="-L$D/lib -lunwstub"
MAKELIBS="-L$D/lib -L/home/claude/vsim/zlib-wasm/lib -lunwstub -lwasmsyms -lffi -lzstd -lz -ldl -lm -Wl,--wrap=close"
export CC="$W/bin/clang --target=wasm32-wasip1 --sysroot=$W/share/wasi-sysroot" AR=$W/bin/llvm-ar RANLIB=$W/bin/llvm-ranlib
export CFLAGS="-O2 $EMU -mllvm -wasm-enable-sjlj -fwasm-exceptions"
MAKECPP="-I$D/compat -include $D/compat/wasi-compat.h"
export LDFLAGS="-lwasi-emulated-signal -lwasi-emulated-process-clocks -lwasi-emulated-mman -lwasi-emulated-getpid -lsetjmp -Wl,-z,stack-size=8388608"
mkdir -p /tmp/claude-0/nvc-bw && cd /tmp/claude-0/nvc-bw
if [ "$1" = configure ] || [ ! -f Makefile ]; then
  /tmp/claude-0/nvc-src/configure --host=wasm32-unknown-wasi --build=x86_64-linux-gnu --disable-llvm --disable-tcl --disable-vital --disable-lto --prefix=/nvc > cfg.log 2>&1
  mkdir -p src/cov; echo '#define GIT_SHA "wasm"' > src/gitsha.h; make src/cov/cov-style.h >/dev/null
fi
rm -f bin/nvc
make -j8 bin/nvc LIBS="$MAKELIBS" CPPFLAGS="$MAKECPP" > make.log 2>&1 || { grep -m5 error make.log; exit 1; }
cp bin/nvc /tmp/claude-0/nvcw/nvc.wasm
echo built $(stat -c %s bin/nvc) bytes
