/* Force-included in the WebAssembly build of nvc. */
#ifndef WASI_COMPAT_H
#define WASI_COMPAT_H
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdio.h>
#include <errno.h>
int dup(int fd);
#include <sys/stat.h>
#include <string.h>
static inline char *mkdtemp(char *t) { static int n = 0; char *x = strstr(t, "XXXXXX"); if (x) { char b[8]; snprintf(b, sizeof b, "%06d", ++n); memcpy(x, b, 6); } return mkdir(t, 0700) == 0 ? t : 0; }
static inline int pipe(int fd[2]) { (void)fd; errno = ENOSYS; return -1; }
static inline int mkstemp(char *t) { (void)t; errno = ENOSYS; return -1; }
static inline int fork(void) { errno = ENOSYS; return -1; }
static inline int execvp(const char *f, char *const a[]) { (void)f; (void)a; errno = ENOSYS; return -1; }
static inline int fpurge(FILE *f) { (void)f; return 0; }
typedef struct { const char *dli_fname; void *dli_fbase; const char *dli_sname; void *dli_saddr; } Dl_info;
static inline int dladdr(const void *a, Dl_info *i) { (void)a; (void)i; return 0; }
#include <signal.h>
#include <sys/types.h>
#ifndef SA_SIGINFO
typedef struct { int si_signo; int si_errno; int si_code; void *si_addr; int si_value; int si_pid; } siginfo_t;
struct sigaction { union { void (*sa_handler)(int); void (*sa_sigaction)(int, siginfo_t *, void *); } __sa; sigset_t sa_mask; int sa_flags; };
#define sa_handler __sa.sa_handler
#define sa_sigaction __sa.sa_sigaction
#define SA_SIGINFO 4
#define SA_RESTART 0x10000000
#define SA_ONSTACK 0x08000000
#define SA_NODEFER 0x40000000
#define SA_RESETHAND 0x80000000
#define SIG_BLOCK 0
#define SIG_UNBLOCK 1
#define SIG_SETMASK 2
#ifndef SIGRTMIN
#define SIGRTMIN 34
#endif
typedef struct { void *ss_sp; int ss_flags; size_t ss_size; } stack_t;
#define SS_DISABLE 2
#define MINSIGSTKSZ 2048
#define SIGSTKSZ 8192
static inline int sigemptyset(sigset_t *s) { (void)s; return 0; }
static inline int sigfillset(sigset_t *s) { (void)s; return 0; }
static inline int sigaddset(sigset_t *s, int n) { (void)s; (void)n; return 0; }
static inline int sigdelset(sigset_t *s, int n) { (void)s; (void)n; return 0; }
static inline int sigismember(const sigset_t *s, int n) { (void)s; (void)n; return 0; }
static inline int sigaction(int n, const struct sigaction *a, struct sigaction *o) { (void)n; (void)a; (void)o; return 0; }
static inline int sigprocmask(int h, const sigset_t *s, sigset_t *o) { (void)h; (void)s; (void)o; return 0; }
static inline int pthread_sigmask(int h, const sigset_t *s, sigset_t *o) { (void)h; (void)s; (void)o; return 0; }
static inline int sigsuspend(const sigset_t *s) { (void)s; return -1; }
static inline int sigaltstack(const stack_t *s, stack_t *o) { (void)s; (void)o; return 0; }
#endif
#include <pthread.h>
#include <setjmp.h>
#ifndef sigsetjmp
#define sigjmp_buf jmp_buf
#define sigsetjmp(b, s) setjmp(b)
#define siglongjmp(b, v) longjmp((b), (v))
#endif
static inline int pthread_kill(pthread_t t, int s) { (void)t; (void)s; return 0; }
#endif
