#ifndef WASI_UCONTEXT_H
#define WASI_UCONTEXT_H
typedef struct { int uc_dummy; } mcontext_t;
typedef struct ucontext_t { mcontext_t uc_mcontext; } ucontext_t;
static inline int getcontext(ucontext_t *u) { (void)u; return -1; }
#endif
