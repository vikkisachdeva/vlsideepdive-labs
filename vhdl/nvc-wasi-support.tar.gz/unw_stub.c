#include <stdint.h>
typedef int (*trace_fn)(void *, void *);
int _Unwind_Backtrace(trace_fn fn, void *arg) { (void)fn; (void)arg; return 5; }
uintptr_t _Unwind_GetIP(void *ctx) { (void)ctx; return 0; }
uintptr_t _Unwind_GetCFA(void *ctx) { (void)ctx; return 0; }
uintptr_t _Unwind_GetIPInfo(void *ctx, int *before) { (void)ctx; if (before) *before = 0; return 0; }
#include <stdio.h>
#include <errno.h>
#include <semaphore.h>
#include <time.h>
FILE *tmpfile(void) { static int n = 0; char name[64]; snprintf(name, sizeof name, "/tmp/tmpfile%d", ++n); return fopen(name, "w+b"); }
int flock(int fd, int op) { (void)fd; (void)op; return 0; }
int sem_init(sem_t *s, int p, unsigned v) { (void)s; (void)p; (void)v; return 0; }
int sem_timedwait(sem_t *s, const struct timespec *t) { (void)s; (void)t; return 0; }

/* dup(): WASI cannot duplicate descriptors, so hand back the same one and
   swallow the matching close() (link with -Wl,--wrap=close). */
static unsigned char dup_count[1024];
int dup(int fd) { if (fd >= 0 && fd < 1024) dup_count[fd]++; return fd; }
int __real_close(int fd);
int __wrap_close(int fd) { if (fd >= 0 && fd < 1024 && dup_count[fd] > 0) { dup_count[fd]--; return 0; } return __real_close(fd); }
