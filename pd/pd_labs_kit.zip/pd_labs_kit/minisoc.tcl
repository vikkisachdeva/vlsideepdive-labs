# Physical design lab: MiniSoC project: the riscv32i core, RTL netlist to routed layout
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit minisoc.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# Synthesis was done with Yosys (synth_riscv.ys in the kit): about 6,100 cells, 1,000+ flip-flops.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog design/riscv.v
link_design riscv
read_sdc design/riscv.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
puts "### STAGE 1_floorplan"

# ---- Floorplan: die and core size from the cell area ----
# core area = standard cell area / utilization; aspect ratio = height / width
initialize_floorplan -utilization 40 -aspect_ratio 1 -core_space 4 -site unithd
source platform/make_tracks.tcl          ;# routing tracks for li1 .. met5
# a first, random pin order: the cells are not placed yet (placement re-places the pins)
place_pins -hor_layers met3 -ver_layers met2 -random
tapcell -distance 14 -tapcell_master sky130_fd_sc_hd__tapvpwrvgnd_1

# ---- Power grid: met1 rails on every row, met4 + met5 straps ----
source platform/global_connect.tcl       ;# VPWR/VPB -> VDD, VGND/VNB -> VSS on every cell
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name grid -voltage_domains CORE -pins met5
add_pdn_stripe -grid grid -layer met1 -width 0.48 -pitch 5.44 -offset 0 -followpins
add_pdn_stripe -grid grid -layer met4 -width 1.6 -pitch 27.2 -offset 13.6
add_pdn_stripe -grid grid -layer met5 -width 1.6 -pitch 27.2 -offset 13.6
add_pdn_connect -grid grid -layers {met1 met4}
add_pdn_connect -grid grid -layers {met4 met5}
pdngen

# ---- Report ----
report_design_area
set die [ord::get_die_area]; set core [ord::get_core_area]
puts [format "die  %.2f x %.2f um" [expr [lindex $die 2]-[lindex $die 0]] [expr [lindex $die 3]-[lindex $die 1]]]
puts [format "core %.2f x %.2f um" [expr [lindex $core 2]-[lindex $core 0]] [expr [lindex $core 3]-[lindex $core 1]]]
puts "rows [llength [[ord::get_db_block] getRows]]"

# ---- Save ----
write_def out/1_floorplan.def
write_db out/1_floorplan.odb

puts "### STAGE 2_place"

# ---- Global placement, design repair, legalization ----
global_placement -density 0.6 -timing_driven
# now that the cells have positions, put each pin next to the logic it connects to
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6 -incremental -timing_driven
write_def out/2_gpl.def                   ;# the global placement, before legalization
estimate_parasitics -placement
repair_design
detailed_placement
check_placement
estimate_parasitics -placement

# ---- Report ----
report_design_area
report_wns
report_tns
report_check_types -max_slew -max_capacitance -max_fanout -violators

# ---- Save ----
write_def out/2_place.def
write_db out/2_place.odb

puts "### STAGE 3_cts"

# ---- Clock tree synthesis ----
clock_tree_synthesis -root_buf sky130_fd_sc_hd__clkbuf_16 \
  -buf_list {sky130_fd_sc_hd__clkbuf_4 sky130_fd_sc_hd__clkbuf_8} -sink_clustering_enable 
set_propagated_clock [all_clocks]
repair_clock_nets
detailed_placement
estimate_parasitics -placement
puts "### Clock tree"
report_clock_skew

# ---- Post-CTS timing repair ----
repair_timing -hold -slack_margin 0.05
repair_timing -setup
detailed_placement
estimate_parasitics -placement
report_worst_slack -max
report_worst_slack -min

# ---- Save ----
write_def out/3_cts.def
write_db out/3_cts.odb

puts "### STAGE 4_route"

# ---- Global routing ----
set_routing_layers -signal met1-met5 -clock met3-met5
set_global_routing_layer_adjustment met1-met5 0.2   ;# fraction of each layer's tracks kept free
global_route -guide_file out/route.guide -allow_congestion -verbose

# ---- Fillers and detailed routing ----
filler_placement {sky130_fd_sc_hd__fill_8 sky130_fd_sc_hd__fill_4 sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_1}
detailed_route -guide out/route.guide -output_drc out/drc.rpt -verbose 1 -droute_end_iter 20 \
  -bottom_routing_layer met1 -top_routing_layer met5
check_antennas -report_file out/antenna.rpt

# ---- Save ----
write_def out/4_route.def
write_db out/4_route.odb

puts "### STAGE 5_signoff"
# ---- Signoff: extraction, timing, power, IR drop ----
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file platform/rcx_patterns.rules
write_spef out/riscv.spef
read_spef out/riscv.spef
report_checks -path_delay max -format full_clock_expanded
report_checks -path_delay min
report_wns
report_tns
report_worst_slack -max
report_worst_slack -min
report_design_area
report_power
set_pdnsim_net_voltage -net VDD -voltage 1.8
analyze_power_grid -net VDD -outfile out/ir_vdd.rpt
write_verilog out/riscv_final.v
