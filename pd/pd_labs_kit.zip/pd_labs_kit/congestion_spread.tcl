# Physical design lab: Congestion and cell padding
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit congestion.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog design/gcd.v
link_design gcd
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer

# ---- Floorplan: die and core size from the cell area ----
# core area = standard cell area / utilization; aspect ratio = height / width
initialize_floorplan -utilization 55 -aspect_ratio 1 -core_space 4 -site unithd
source platform/make_tracks.tcl          ;# routing tracks for li1 .. met5
# a first, random pin order: the cells are not placed yet (placement re-places the pins)
place_pins -hor_layers met3 -ver_layers met2 -random
tapcell -distance 14 -tapcell_master sky130_fd_sc_hd__tapvpwrvgnd_1

# ---- Power grid: met1 rails on every row, met4 + met5 straps ----
source platform/global_connect.tcl       ;# VPWR/VPB -> VDD, VGND/VNB -> VSS on every cell
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name grid -voltage_domains CORE -pins met5
add_pdn_stripe -grid grid -layer met1 -width 0.48 -pitch 5.44 -offset 0 -followpins
add_pdn_stripe -grid grid -layer met4 -width 1.6 -pitch 27.2 -offset 13.6
add_pdn_stripe -grid grid -layer met5 -width 1.6 -pitch 27.2 -offset 13.6
add_pdn_connect -grid grid -layers {met1 met4}
add_pdn_connect -grid grid -layers {met4 met5}
pdngen

# ---- Cell padding: empty sites left and right of every cell ----
# (none)

# ---- Global placement, design repair, legalization ----
global_placement -density 0.65 -timing_driven
# now that the cells have positions, put each pin next to the logic it connects to
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.65 -incremental -timing_driven
write_def out/2_gpl.def                   ;# the global placement, before legalization
estimate_parasitics -placement
repair_design
detailed_placement
check_placement
estimate_parasitics -placement

# ---- Global routing ----
set_routing_layers -signal met1-met5 -clock met3-met5
set_global_routing_layer_adjustment met1-met5 0.7   ;# fraction of each layer's tracks kept free
global_route -guide_file out/route.guide -allow_congestion -verbose

# ---- Save ----
write_def out/2_place.def
write_db out/2_place.odb
