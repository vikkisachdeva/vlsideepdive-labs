# Physical design lab: CTS settings: clustering and buffers
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit cts_options.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db riscv_results/2_place.odb       ;# the design as the previous stage left it
read_sdc design/riscv.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
# (the riscv32i core: 1,000+ flip-flops on one clock)

# ---- Clock tree synthesis ----
clock_tree_synthesis -root_buf sky130_fd_sc_hd__clkbuf_16 \
  -buf_list {sky130_fd_sc_hd__clkbuf_4 sky130_fd_sc_hd__clkbuf_8} -sink_clustering_enable -sink_clustering_size 5 -sink_clustering_max_diameter 20
set_propagated_clock [all_clocks]
repair_clock_nets
detailed_placement
estimate_parasitics -placement
puts "### Clock tree"
report_clock_skew
report_worst_slack -max

# ---- Save ----
write_def out/3_cts.def
write_db out/3_cts.odb
