# Physical design lab: Hold fixing after CTS
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit hold.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/2_place.odb       ;# the design as the previous stage left it
read_sdc design/gcd_hold.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer

# ---- Clock tree synthesis ----
clock_tree_synthesis -root_buf sky130_fd_sc_hd__clkbuf_16 \
  -buf_list {sky130_fd_sc_hd__clkbuf_4 sky130_fd_sc_hd__clkbuf_8} -sink_clustering_enable 
set_propagated_clock [all_clocks]
repair_clock_nets
detailed_placement
estimate_parasitics -placement
puts "### Clock tree"
report_clock_skew
puts "### Hold before repair"
report_worst_slack -min

# ---- Hold repair: insert delay buffers on short paths ----
repair_timing -hold -slack_margin 0.05
detailed_placement
estimate_parasitics -placement
puts "### Timing"
report_worst_slack -min
report_worst_slack -max
report_check_types -min_delay -violators

# ---- Save ----
write_def out/3_cts.def
write_db out/3_cts.odb
