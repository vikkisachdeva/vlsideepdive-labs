# Physical design lab: Physical verification: DRC, antenna, connectivity
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit verify.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/4_route.odb       ;# the design as the previous stage left it
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
# ---- DRC: the detailed router's own design rule check (out/drc.rpt from the routing lab) ----
# ---- Placement legality: every cell on a site, no overlaps ----
check_placement -verbose
# ---- Antennas ----
check_antennas -report_file out/antenna.rpt
# ---- Connectivity: unrouted or open nets ----
set b [ord::get_db_block]; set open 0
foreach net [$b getNets] {
  if {[$net getSigType] == "POWER" || [$net getSigType] == "GROUND"} continue
  if {[$net getWire] == "NULL" && [llength [$net getITerms]] + [llength [$net getBTerms]] > 1} { incr open }
}
puts "### Nets without routing: $open"
