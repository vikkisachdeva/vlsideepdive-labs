# Physical design lab: Timing ECO after routing
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit eco.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/4_route.odb       ;# the design as the previous stage left it
read_sdc design/gcd_eco.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
set_propagated_clock [all_clocks]
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file platform/rcx_patterns.rules
write_spef out/before.spef
read_spef out/before.spef
puts "### Before ECO"
report_worst_slack -max
report_tns
# ---- ECO: free the filler space, repair setup, then route the changes ----
set b [ord::get_db_block]
foreach inst [$b getInsts] { if {[string match "*__fill_*" [[$inst getMaster] getName]]} { odb::dbInst_destroy $inst } }
repair_timing -setup
detailed_placement
# the old wires do not fit the moved cells: remove them and route again
foreach net [$b getNets] { set w [$net getWire]; if {$w != "NULL"} { odb::dbWire_destroy $w } }

# ---- Global routing ----
set_routing_layers -signal met1-met5 -clock met3-met5
set_global_routing_layer_adjustment met1-met5 0.2   ;# fraction of each layer's tracks kept free
global_route -guide_file out/route.guide -allow_congestion -verbose

# ---- Fillers and detailed routing ----
filler_placement {sky130_fd_sc_hd__fill_8 sky130_fd_sc_hd__fill_4 sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_1}
detailed_route -guide out/route.guide -output_drc out/drc.rpt -verbose 1 \
  -bottom_routing_layer met1 -top_routing_layer met5
extract_parasitics -ext_model_file platform/rcx_patterns.rules
write_spef out/after.spef
read_spef out/after.spef
puts "### After ECO"
report_worst_slack -max
report_tns

# ---- Save ----
write_def out/4_route.def
write_db out/4_route.odb
