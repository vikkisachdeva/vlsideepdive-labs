# Physical design lab: Timing ECO after routing
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit eco.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/4_route.odb       ;# the design as the previous stage left it
read_sdc design/gcd_eco.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
set_propagated_clock [all_clocks]
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file platform/rcx_patterns.rules
write_spef out/before.spef
read_spef out/before.spef
puts "### Before ECO"
report_worst_slack -max
report_tns
# (no ECO)
