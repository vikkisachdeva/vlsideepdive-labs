# Physical design lab: Placement blockages
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit blockage.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/1_floorplan.odb       ;# the design as the previous stage left it
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer

# ---- Placement blockage ----
set b [ord::get_db_block]; set c [ord::get_core_area]
set cx [expr ([lindex $c 0]+[lindex $c 2])/2]; set cy [expr ([lindex $c 1]+[lindex $c 3])/2]
# no cell may be placed in a 24 x 24 um square in the middle of the core
odb::dbBlockage_create $b [expr int(($cx-12)*1000)] [expr int(($cy-12)*1000)] [expr int(($cx+12)*1000)] [expr int(($cy+12)*1000)]

# ---- Global placement, design repair, legalization ----
global_placement -density 0.6 -timing_driven -max_phi_coef 1.04
# now that the cells have positions, put each pin next to the logic it connects to
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6 -incremental -timing_driven -max_phi_coef 1.04
write_def out/2_gpl.def                   ;# the global placement, before legalization
estimate_parasitics -placement
repair_design
detailed_placement
check_placement
estimate_parasitics -placement

# ---- Report ----
report_design_area
report_wns
report_tns
report_check_types -max_slew -max_capacitance -max_fanout -violators

# ---- Save ----
write_def out/2_place.def
write_db out/2_place.odb
