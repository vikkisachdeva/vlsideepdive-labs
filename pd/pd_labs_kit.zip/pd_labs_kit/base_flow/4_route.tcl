# Physical design lab: the base flow, stage 4_route
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit 4_route.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/3_cts.odb       ;# the design as the previous stage left it
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
set_propagated_clock [all_clocks]

# ---- Global routing ----
set_routing_layers -signal met1-met5 -clock met3-met5
set_global_routing_layer_adjustment met1-met5 0.2   ;# fraction of each layer's tracks kept free
global_route -guide_file out/route.guide -allow_congestion -verbose

# ---- Fillers and detailed routing ----
filler_placement {sky130_fd_sc_hd__fill_8 sky130_fd_sc_hd__fill_4 sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_1}
detailed_route -guide out/route.guide -output_drc out/drc.rpt -verbose 1 \
  -bottom_routing_layer met1 -top_routing_layer met5
check_antennas -report_file out/antenna.rpt

# ---- Save ----
write_def out/4_route.def
write_db out/4_route.odb
