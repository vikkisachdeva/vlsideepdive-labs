# Physical design lab: Signoff STA with extracted parasitics
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit signoff_sta.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/4_route.odb       ;# the design as the previous stage left it
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
set_propagated_clock [all_clocks]
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file platform/rcx_patterns.rules
write_spef out/gcd.spef
read_spef out/gcd.spef
report_checks -path_delay max -format full_clock_expanded
report_checks -path_delay min
report_wns
report_tns
report_power
write_verilog out/gcd_final.v
