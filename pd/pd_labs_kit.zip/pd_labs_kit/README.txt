vlsideepdive physical design labs: OpenROAD scripts for Sky130 HD.

1. Install OpenROAD (OpenROAD-flow-scripts Docker image, or: micromamba create -n pd -c litex-hub -c conda-forge openroad).
2. Copy flow/platforms/sky130hd from OpenROAD-flow-scripts into platform/ (platform/lef, platform/lib, ...).
3. Run a lab:  openroad -exit floorplan.tcl
Scripts read design/ and results/ (the base gcd run that later labs start from) and write to out/.
The CTS settings lab (cts_options*.tcl) uses riscv_results/: the placed riscv32i core.
Each lab has one script per setting shown on the web page: <script>_<setting>.tcl.
