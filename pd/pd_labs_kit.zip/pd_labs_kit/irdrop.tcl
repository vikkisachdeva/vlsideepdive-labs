# Physical design lab: IR drop and electromigration
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit irdrop.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/4_route.odb       ;# the design as the previous stage left it
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer
set_propagated_clock [all_clocks]
# ---- Static IR drop and EM on VDD (PDNSim) ----
set_pdnsim_net_voltage -net VDD -voltage 1.8
analyze_power_grid -net VDD -outfile out/ir_vdd.rpt -enable_em -em_outfile out/em_vdd.rpt
set_pdnsim_net_voltage -net VSS -voltage 0
analyze_power_grid -net VSS -outfile out/ir_vss.rpt
