# gcd: one clock, 6.0 ns (167 MHz): tight, for the timing-driven placement lab at the typical corner
create_clock -name core_clock -period 6.0 [get_ports clk]
set_input_delay  0.5 -clock core_clock [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 0.5 -clock core_clock [all_outputs]
set_load 0.01 [all_outputs]
