# gcd: one clock, 7.5 ns, plus 0.4 ns of hold uncertainty (clock jitter and skew margin)
create_clock -name core_clock -period 7.5 [get_ports clk]
set_input_delay  0.5 -clock core_clock [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 0.5 -clock core_clock [all_outputs]
set_load 0.01 [all_outputs]
set_clock_uncertainty -hold 0.4 [all_clocks]
