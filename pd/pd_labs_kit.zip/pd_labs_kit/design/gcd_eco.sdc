# gcd: one clock, 7.0 ns: the clock was sped up after routing
create_clock -name core_clock -period 7.0 [get_ports clk]
set_input_delay  0.5 -clock core_clock [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 0.5 -clock core_clock [all_outputs]
set_load 0.01 [all_outputs]
