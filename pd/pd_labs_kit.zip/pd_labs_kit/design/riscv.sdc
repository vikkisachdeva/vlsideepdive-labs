# MiniSoC project: the riscv32i core, one 15 ns clock (66 MHz) at the typical corner
create_clock -name clk -period 15.0 [get_ports clk]
set_input_delay  2.0 -clock clk [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 2.0 -clock clk [all_outputs]
set_load 0.02 [all_outputs]
