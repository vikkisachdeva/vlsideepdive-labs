# Physical design lab: Macro placement, halo and keep-out
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit macro.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_lef design/ram32x8.lef              ;# the RAM macro: abstract view
read_liberty design/ram32x8.lib          ;# the RAM macro: timing
read_verilog design/macro_top.v
link_design macro_top
read_sdc design/macro_top.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer

initialize_floorplan -utilization 25 -aspect_ratio 1 -core_space 4 -site unithd
source platform/make_tracks.tcl

# ---- Place the macro ----
# Let the macro placer choose: halo 5 um, channel 10 um, corner placement
global_placement -density 0.5
macro_placement -halo {5 5} -channel {10 10} -style corner_min_wl

place_pins -hor_layers met3 -ver_layers met2 -random
tapcell -distance 14 -tapcell_master sky130_fd_sc_hd__tapvpwrvgnd_1 -halo_width_x 2 -halo_width_y 2

# ---- Global placement, design repair, legalization ----
global_placement -density 0.6 
# now that the cells have positions, put each pin next to the logic it connects to
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6 -incremental 
write_def out/2_gpl.def                   ;# the global placement, before legalization
estimate_parasitics -placement
repair_design
detailed_placement
check_placement
estimate_parasitics -placement

# ---- Global routing ----
set_routing_layers -signal met1-met5 -clock met3-met5
set_global_routing_layer_adjustment met1-met5 0.3   ;# fraction of each layer's tracks kept free
global_route -guide_file out/route.guide -allow_congestion -verbose

puts "### Placement wirelength"

# ---- Report ----
report_design_area
report_wns
report_tns
report_check_types -max_slew -max_capacitance -max_fanout -violators

# ---- Save ----
write_def out/2_place.def
write_db out/2_place.odb
