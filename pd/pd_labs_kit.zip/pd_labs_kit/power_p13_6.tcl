# Physical design lab: Power planning and IR drop
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit power.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog design/gcd.v
link_design gcd
read_sdc design/gcd.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer

# ---- Floorplan: die and core size from the cell area ----
# core area = standard cell area / utilization; aspect ratio = height / width
initialize_floorplan -utilization 40 -aspect_ratio 1 -core_space 4 -site unithd
source platform/make_tracks.tcl          ;# routing tracks for li1 .. met5
# a first, random pin order: the cells are not placed yet (placement re-places the pins)
place_pins -hor_layers met3 -ver_layers met2 -random
tapcell -distance 14 -tapcell_master sky130_fd_sc_hd__tapvpwrvgnd_1

# ---- Power grid: met1 rails on every row, met4 + met5 straps ----
source platform/global_connect.tcl       ;# VPWR/VPB -> VDD, VGND/VNB -> VSS on every cell
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name grid -voltage_domains CORE -pins met5
add_pdn_stripe -grid grid -layer met1 -width 0.48 -pitch 5.44 -offset 0 -followpins
add_pdn_stripe -grid grid -layer met4 -width 1.6 -pitch 13.6 -offset 6.8
add_pdn_stripe -grid grid -layer met5 -width 1.6 -pitch 13.6 -offset 6.8
add_pdn_connect -grid grid -layers {met1 met4}
add_pdn_connect -grid grid -layers {met4 met5}
pdngen

# ---- Global placement, design repair, legalization ----
global_placement -density 0.6 -timing_driven
# now that the cells have positions, put each pin next to the logic it connects to
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6 -incremental -timing_driven
write_def out/2_gpl.def                   ;# the global placement, before legalization
estimate_parasitics -placement
repair_design
detailed_placement
check_placement
estimate_parasitics -placement

# ---- Static IR drop on VDD (PDNSim): currents from the cell power ----
set_pdnsim_net_voltage -net VDD -voltage 1.8
analyze_power_grid -net VDD -outfile out/ir_vdd.rpt

# ---- Save ----
write_def out/2_place.def
write_db out/2_place.odb
