# Physical design lab: Inputs: technology, cells and libraries
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit inputs.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib

# ---- The metal stack (from the technology LEF) ----
set tech [[ord::get_db] getTech]
puts "### Routing layers"
puts [format "%-6s %-11s %7s %7s" layer direction pitch width]
foreach layer [$tech getLayers] {
  if {[$layer getType] != "ROUTING"} continue
  puts [format "%-6s %-11s %7.2f %7.2f" [$layer getName] [$layer getDirection] \
        [expr [$layer getPitch]/1000.0] [expr [$layer getWidth]/1000.0]]
}
# ---- The standard cell site: every cell is a multiple of it ----
foreach lib [[ord::get_db] getLibs] {
  foreach site [$lib getSites] {
    puts [format "### Site %s: %.2f x %.2f um" [$site getName] [expr [$site getWidth]/1000.0] [expr [$site getHeight]/1000.0]]
  }
}
# ---- Cells: drive strengths and special cells ----
puts "### Cells"
puts [format "%-34s %8s %8s" cell width height]
foreach name {inv_1 inv_2 inv_4 inv_8 inv_16 buf_1 buf_4 buf_16 nand2_1 nand2_4 dfxtp_1 dfrtp_1 \
              clkbuf_4 clkbuf_16 tapvpwrvgnd_1 fill_1 fill_8 decap_4 decap_12 conb_1 diode_2} {
  set m [[ord::get_db] findMaster sky130_fd_sc_hd__$name]
  puts [format "%-34s %8.2f %8.2f" [$m getName] [expr [$m getWidth]/1000.0] [expr [$m getHeight]/1000.0]]
}
