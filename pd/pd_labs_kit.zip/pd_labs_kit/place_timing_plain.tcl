# Physical design lab: Timing-driven placement and design repair
# Tools: OpenROAD (open source), Sky130 HD standard cells. Run it yourself with:
#   openroad -exit place_timing.tcl
# Inputs from earlier labs are in results/, this lab writes to out/.
# ---- Technology, cell library, timing library ----
read_lef platform/lef/sky130_fd_sc_hd.tlef
read_lef platform/lef/sky130_fd_sc_hd_merged.lef
read_liberty platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_db results/1_floorplan.odb       ;# the design as the previous stage left it
read_sdc design/gcd_fast.sdc
source platform/setRC.tcl                ;# wire resistance and capacitance per layer

# ---- Global placement, design repair, legalization ----
global_placement -density 0.6 
# now that the cells have positions, put each pin next to the logic it connects to
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6 -incremental 
write_def out/2_gpl.def                   ;# the global placement, before legalization
estimate_parasitics -placement
detailed_placement
check_placement
estimate_parasitics -placement

# ---- Report ----
report_design_area
report_wns
report_tns
report_check_types -max_slew -max_capacitance -max_fanout -violators

# ---- Save ----
write_def out/2_place.def
write_db out/2_place.odb
